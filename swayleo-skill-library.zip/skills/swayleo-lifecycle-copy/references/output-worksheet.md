# swayleo-lifecycle-copy output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Email: campaign ID, subject, preview, lead/header, body sections, CTA label/destination and relevant disclaimer. SMS: message, destination and flagged consent/opt-out requirements. Include open facts separately.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
The message has one job; claims and terms match evidence; proof fits the product; CTA matches destination; variables have fallbacks; review state is explicit.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
