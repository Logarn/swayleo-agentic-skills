# swayleo-operations-call output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Opening decisions: issue / decision needed / recommendation / owner. Then short operations bullets. End with Priority | Action | Owner | Due | Blocker | Source. Write in plain, informal language.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
The top items require a real decision; old unresolved actions remain traceable; dates are current; completion and approval claims have evidence.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
