# swayleo-email-design-qa output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Campaign/frame | Finding | Evidence | Expected change | Owner/reviewer | Severity | Status. Add coverage: reviewed, missing, plain-text and unverified build behavior.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
All requested frames are accounted for; comments are actionable; actual links are distinguished from labels; visible QA is not presented as send approval.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
