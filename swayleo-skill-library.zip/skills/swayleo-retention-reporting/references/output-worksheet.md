# swayleo-retention-reporting output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Metric definitions; scorecard; period/cohort comparison; validated drivers; limitations; prioritized next actions. Keep calculations inspectable.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Definitions and denominators clear; sources reconcile; overlaps disclosed; cohorts eligible; uncertainty visible; actions follow the evidence.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
