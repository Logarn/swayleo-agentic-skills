# swayleo-copy-document-structure output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Updated target sections; table-count/label checks; preserved-copy check; rendered layout findings; unresolved template decisions.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Correct master and overrides; actual labels verified; existing copy/comments retained; native controls remain native; layout proof supports readiness.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
