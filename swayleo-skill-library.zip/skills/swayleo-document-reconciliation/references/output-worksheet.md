# swayleo-document-reconciliation output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Difference register; source precedence decisions; planned/applied changes; preserved anchors; unresolved review items.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Canonical versions identified; authority documented; comments preserved; concurrency handled; supplied copy retained; client-facing scope respected.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
