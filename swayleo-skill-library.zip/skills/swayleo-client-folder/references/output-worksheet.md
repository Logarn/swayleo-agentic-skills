# swayleo-client-folder output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Document register: purpose | canonical link | owner | freshness | completeness | next action. If creating files, include new IDs/locations and migration gaps.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Four core documents are covered; optional map is labelled; template readiness is checked; no old-client residue is carried forward; links resolve.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
