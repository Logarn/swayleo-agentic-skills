# swayleo-segmentation-strategy output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Current definition register; gaps/overlaps; proposed segment specifications; priority backlog; measurement and review plan. Use ALL/ANY groups with explicit parentheses.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Definitions are reproducible; windows and exclusions are explicit; counts are dated; representative profiles match; proposed audiences are not claimed live.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
