# swayleo-campaign-calendar output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Campaign ID | Date/time/zone | Channel | Job | Angle | Audience/exclusions | Product | Offer/expiry | CTA | Owner | Dependencies | Approval state. Add a short monthly strategy summary.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Every campaign has an audience and job; offer mechanics are sourced; calendar and brief agree; unrelated months remain intact; proposals remain labelled.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
