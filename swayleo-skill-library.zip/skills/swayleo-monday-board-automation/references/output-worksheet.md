# swayleo-monday-board-automation output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Board map; automation register; rule specifications; test matrix/run evidence; known limits and proposed next steps.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Actual schema; no overlapping rules; reviewer mapping correct; recurrence/replay checked; date semantics explicit; activation claims supported.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
