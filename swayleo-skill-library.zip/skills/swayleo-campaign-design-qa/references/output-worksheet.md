# swayleo-campaign-design-qa output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Coverage table and prioritized findings with exact anchors. A clean review means no new observed defects in the reviewed scope, not universal approval.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
All requested designs accounted for; current frames reviewed; duplicate findings removed; anchors precise; untested links/client renders stated.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
