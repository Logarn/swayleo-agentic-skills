# swayleo-brand-context output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
One-page working brief; source/decision ledger; unresolved facts; canonical-link register; task-specific constraints.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Every material claim has a source; proposals and approvals are distinct; identity/account/month match; brand-specific assumptions are not imported.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
