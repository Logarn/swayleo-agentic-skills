# swayleo-flow-strategy output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Flow setup; six-column review map; detailed per-email briefs; copy-section mapping; technical checks; approval state.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Trigger matches the event; branches/counts/timing are coherent; each email has one job; detailed briefs match the map; approval and technical checks remain distinct.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
