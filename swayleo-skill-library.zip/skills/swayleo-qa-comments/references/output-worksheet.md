# swayleo-qa-comments output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Comment draft or verified edit: target/anchor | text | source | thread ID/link | saved/draft state. Keep the summary short.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Current evidence; specific correction; correct author/anchor; no duplicate thread; save state verified; no unintended body edit or send.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
