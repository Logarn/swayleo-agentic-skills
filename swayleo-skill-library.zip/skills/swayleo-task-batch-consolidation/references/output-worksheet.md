# swayleo-task-batch-consolidation output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Before/after register; original ID → batch ID mapping; copied-content verification; archive results; uncertain actions and recovery route.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Membership exact; full content retained; replacements verified first; original history preserved; archive state read back; no unsupported preservation claim.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
