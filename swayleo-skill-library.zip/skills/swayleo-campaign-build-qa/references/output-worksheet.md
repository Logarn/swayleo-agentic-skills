# swayleo-campaign-build-qa output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Preflight checklist with evidence; audience and schedule readback; link/dynamic-content tests; unresolved blockers; ready-for-approval versus scheduled/sent state.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Correct revision/account; audience/exclusions verified; actual links tested; dynamic fallbacks checked; render/schedule verified; send approval separate.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
