# swayleo-flow-build-qa output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Settings comparison; test matrix with expected/observed behavior; evidence links; blockers; activation state.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Correct account; settings read directly; negative cases covered; consent/exit logic checked; uncertain checks remain unverified; no accidental activation.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
