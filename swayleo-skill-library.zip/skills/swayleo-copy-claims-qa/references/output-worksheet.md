# swayleo-copy-claims-qa output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Location | Current wording | Issue | Evidence | Proposed change/question | Owner | Status. Include unresolved facts that block design or send readiness.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
All material claims/terms are sourced; exact products and timeframes match; channels agree; proposed replacements are not falsely labelled approved.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
