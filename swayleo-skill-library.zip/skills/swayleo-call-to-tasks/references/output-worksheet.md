# swayleo-call-to-tasks output worksheet

## Context
- Brand / project:
- Requested scope:
- Source revision / date checked:
- Current state and expected result:

## Required output
Task | Client | Owner | Due date + timezone | Deadline basis | Acceptance criteria | Source | Existing task ID | Action/status. Follow with decisions and questions that did not become tasks.

## Evidence and decisions
| Finding / decision | Source | Confirmed / proposed / unresolved | Practical effect | Owner / next action |
| --- | --- | --- | --- | --- |

## Completion check
Verify every task against its source; explicit dates beat defaults; unresolved fields are visible; existing-task matches are checked; created records are read back.

## Result
- Completed and verified:
- Drafts or proposed work:
- Unresolved inputs or checks:
