# Email Love ESP Skills

Free, open-source AI skills for the personalization languages inside email service providers — the merge tags, conditionals, and loops that decide what each subscriber actually sees.

Built and maintained by [Email Love](https://www.emaillove.com). Works in **Claude** and **ChatGPT**.

> **Beta.** The content is grounded in first-party documentation and measured against a no-skill baseline, but the suites are small, one Customer.io behaviour is unverified end to end (see [Known limitations](#known-limitations)), and nothing here has been through a stable release. Use it, and report what it gets wrong.

## Why these exist

Every ESP has its own templating language, and general-purpose AI is confidently wrong about them in ways that survive review.

The failure mode is the problem. These aren't errors you catch in the editor — they're errors you catch in the inbox, in a support ticket three days later, or never, because the message quietly didn't send at all.

Three real examples from the baseline runs behind these skills:

- Asked for Iterable Handlebars, it produced `{{subtract}}`, `{{toFixed}}`, `{{#with}}` and `timeZone=`. None exist in Iterable. All save without error and fail at send time.
- Asked to render a deadline in the recipient's timezone in Customer.io, it asserted no such filter exists and hand-rolled a 25-branch block hardcoding UTC offsets — correct for one week of the year, silently wrong across every DST boundary. The real answer is one argument on the `date` filter.
- Asked to list a person's related objects in Customer.io, it stated flatly that the platform can't do it and proposed three engineering workarounds. `objects.<plural>[n]` does exactly that.

Each skill encodes what a platform *actually* supports, what it doesn't, and which mistakes cost you a send rather than a space.

## Skills

| Skill | Platform | Language | Status |
|---|---|---|---|
| [`iterable-handlebars`](skills/iterable-handlebars) | Iterable | Handlebars (handlebars.java) | 🧪 Beta |
| [`klaviyo-django`](skills/klaviyo-django) | Klaviyo | **Django templates** — not Liquid | 🧪 Beta |
| [`braze-liquid`](skills/braze-liquid) | Braze | Liquid 5 (Shopify), partial | 🧪 Beta |
| [`customerio-liquid`](skills/customerio-liquid) | Customer.io | Liquid — two engines, set per message | 🧪 Beta |
| [`sfmc-ampscript`](skills/sfmc-ampscript) | Salesforce Marketing Cloud | AMPscript, GTL, SSJS | 🧪 Beta |
| [`marketo-velocity`](skills/marketo-velocity) | Marketo Engage | Tokens + Velocity | 🧪 Beta |
| [`hubspot-hubl`](skills/hubspot-hubl) | HubSpot | HubL (Jinjava) | 🧪 Beta |
| [`moengage-jinja`](skills/moengage-jinja) | MoEngage | Jinja | 🧪 Beta |
| [`sailthru-zephyr`](skills/sailthru-zephyr) | Sailthru / Zeta Engage | **Zephyr** — single braces, no filters | 🧪 Beta |
| [`zeta-zml`](skills/zeta-zml) | Zeta Marketing Platform | ZML — Liquid-derived | 🧪 Beta |
| `mailchimp-merge-tags` | Mailchimp | Merge tags | 🔜 Planned |

Want one prioritized? [Open an issue](../../issues).

### A note on Klaviyo

Klaviyo is widely described as using Liquid. It does not — it runs the **Django** template language with a set of Liquid-*named* filter aliases bolted on. The filters read like Liquid; the tags and control flow are Django, and the difference is not cosmetic:

| Written as | Result |
|---|---|
| `{% elsif %}` | **HTTP 400 — hard error.** It's `{% elif %}` |
| `{% assign x = 1 %}` | **HTTP 400.** There is no `assign`; use `{% with %}` |
| `{{ items.size }}` | Renders empty. It's `{{ items\|length }}` |
| `{{ p \| lookup: 'Name' }}` | **HTTP 400.** A space after the colon is fatal |

That last form appears in Klaviyo's own custom-objects documentation. All four verified against Klaviyo's `/api/template-render` endpoint, not inferred from docs.

Klaviyo's developer documentation says so directly — the page is slugged `django_message_design` and links out to Django's own builtins reference:

> "Klaviyo supports most of the filters used by the **Django template language**"

> "**Django template variables** cannot include spaces or special characters such as hyphens."

— [Message design overview](https://developers.klaviyo.com/en/docs/django_message_design)

And the render API's own error text names the engine: *"Please check included **django** syntax and ensure it is compatible with provided context."*

## Designing the email in Figma

Every skill also covers applying its language inside a Figma file built with the [Email Love plugin](https://www.emaillove.com/figma-plugin), which is a different problem from writing the code in the ESP. The language is identical — the plugin inserts your templating code as-is and validates none of it — but placement is not, and the plugin's preview does not render code blocks, so nothing is visible before export.

The rule that matters most: **paired Code Blocks must be siblings at the same nesting level.** Both between wrappers, both between sections, or both inside the same column. Compiled on MJML 4.18, a pair spanning two levels with the condition false leaves three orphaned `</table>`, `</tr>`, and `</td>` tags and an Outlook conditional-table depth of `-2`. The same pair as siblings, wrapping a two-column section and a wrapper and a full-width section at once, is balanced at depth `0`.

It fails quietly, too. The condition is true in your test send, so nothing looks wrong; it only breaks for recipients on the other branch, and it breaks worst in Outlook.

A second one, found the same way: a **double-quoted string argument in a link field silently truncates the link.** `{{ slug|default:"home" }}` in an href compiles without complaint at MJML's default validation level and ships as `href="https://x.com/{{ slug|default:"`. Klaviyo and Salesforce Marketing Cloud both write double quotes in their own documentation, so this is a copy-paste away on either.

Each skill's `references/figma-export.md` has the rest, including the specifics of that platform's export target — Braze Content Blocks dropping the `<head>`, Iterable snippets carrying no CSS, Marketo's reserved words breaking a link URL, SFMC impression regions taking their names from Figma layer names.

## Choose your skill

| Your ESP | Skill | Try it with |
|---|---|---|
| Iterable | [`iterable-handlebars`](skills/iterable-handlebars) | "Why is my Iterable cart loop rendering blank for some users?" |
| Klaviyo | [`klaviyo-django`](skills/klaviyo-django) | "Write a Klaviyo block that shows different copy per loyalty tier." |
| Braze | [`braze-liquid`](skills/braze-liquid) | "My Braze campaign sent to half the audience and stopped. Why?" |
| Customer.io | [`customerio-liquid`](skills/customerio-liquid) | "Some Customer.io deliveries show as Failed, not bounced. What's happening?" |
| Salesforce Marketing Cloud | [`sfmc-ampscript`](skills/sfmc-ampscript) | "Subscribers are showing as Errored on this AMPscript send." |
| Marketo Engage | [`marketo-velocity`](skills/marketo-velocity) | "This Marketo email won't validate and there's no scripting in it." |
| HubSpot | [`hubspot-hubl`](skills/hubspot-hubl) | "Why is my default value not working on a HubSpot contact token?" |
| MoEngage | [`moengage-jinja`](skills/moengage-jinja) | "My MoEngage campaign reached far fewer users than the segment. Why?" |
| Sailthru / Zeta Engage | [`sailthru-zephyr`](skills/sailthru-zephyr) | "This Sailthru campaign sent, but the email arrived empty." |
| Zeta Marketing Platform | [`zeta-zml`](skills/zeta-zml) | "Some messages in this Zeta campaign show as skipped. What causes that?" |

Install only the one you use. Each skill is deliberately scoped to a single platform and tells the model not to apply itself to the others, so installing all ten is fine but installing one is better.

**Zeta ships two email platforms and they speak different languages.** Zeta Marketing Platform uses ZML, which is Liquid-derived. Zeta Engage by Sailthru uses Zephyr, which is single-brace and has no filter pipe. If you are not sure which one you are on, look at an existing template: `{% if %}` means ZML, `{if}` means Zephyr.

## Install

### Start here: which install do you want?

Two routes carry these skills, and you probably only need one:

- **Already using an Email Love plugin?** Check before installing anything here. The official
  [Email Love ChatGPT/Codex plugin](https://chatgpt.com/plugins/plugins_6a739f43c3b48191b1281a9b2d48b409)
  bundles ALL TEN of these ESP skills alongside the Figma workflows, and the Claude Code
  marketplace bundle `emaillove-esp@email-love` (from
  [email-love/claude-skills](https://github.com/email-love/claude-skills)) installs the same
  ten in one step. Installing individual skills on top of those creates duplicates.
- **Just want ESP help for one platform?** Install a single skill from this repository using
  the routes below. ESP advice and HTML personalization need **no Figma connection and no
  Email Love MCP** — a skill plus your email HTML is the whole setup.

Artifacts differ: a standalone `.skill` file is ONE skill for direct upload; the combined
plugin ZIPs live in the other repositories and carry all fourteen skills. Uploaded copies are
snapshots — a change in this repository does not update anything already uploaded or
published. To see what you are running, ask the skill: each one states its version, and
`claude plugin details` shows the installed version in Claude Code.

First prompt to try, on any platform:

> I use [ESP]. Here is my email HTML and an anonymized example of the [event/profile] data.
> Add [personalization requirement], preserve the existing design, and tell me how to test
> missing values and empty lists. Ask if you need to know my message type or template engine.

And when something already broke:

> This [ESP] email renders blank for some recipients. Here is the template and an anonymized
> example of a recipient it fails for. Diagnose the cause first; do not rewrite anything yet.

### Claude Code

```bash
claude plugin marketplace add email-love/esp-skills
claude plugin install klaviyo-django@email-love-esp
```

Update with `claude plugin marketplace update email-love-esp`, then `claude plugin update klaviyo-django@email-love-esp`. Remove with `claude plugin uninstall klaviyo-django@email-love-esp`.

Verified against Claude Code 2.1.241: the marketplace resolves, the plugin installs at the version in `VERSION`, an install from 1.5.0 updates in place, and `claude plugin details` reports roughly 260 tokens always-on with about 4.9k paid when the skill actually fires.

### Claude apps (web, desktop, Cowork)

Add this repository as a marketplace: **Customize → Plugins → Add → Add marketplace**, enter `email-love/esp-skills`, then install the plugin for your platform, such as **Klaviyo Personalization**. **Check for updates** on the marketplace pulls new versions, or turn on **Sync automatically**.

To install without a marketplace, upload the skill instead. Build the `.skill` file for your platform (`bash scripts/build.sh` produces all ten in `dist/`), or download it from [Releases](../../releases). Then **Customize → Skills → + → Create skill → Upload a skill**.

An uploaded skill is a snapshot, not a subscription. It does not update itself — to move to a new version, download the new `.skill` and upload it again; same name replaces the old one. Remove it from the same screen.

### ChatGPT

These follow the [Agent Skills open standard](https://help.openai.com/en/articles/20001066-skills-in-chatgpt), so the same folder works unmodified. Build the `.skill` with `bash scripts/build.sh` (or use [Releases](../../releases)), then **Skills → Create → Upload from your computer**. Requires a Business, Enterprise, Healthcare, or Edu plan. Updates and removal work the same way as the Claude apps: re-upload to update, delete to remove.

`agents/openai.yaml` supplies the display name, blurb, and default prompt ChatGPT shows. Claude ignores that file.

### Codex

Codex reads the same directory layout. Clone and copy the skill you want into your Codex skills directory:

```bash
git clone https://github.com/email-love/esp-skills.git
cp -r esp-skills/skills/klaviyo-django ~/.codex/skills/
```

### Manually, into Claude Code

```bash
git clone https://github.com/email-love/esp-skills.git
cp -r esp-skills/skills/klaviyo-django ~/.claude/skills/
```

Once installed, skills trigger on their own. You don't invoke them — ask a question about your ESP's templating and the right one loads.

### Verifying a download

Every release ships `SHA256SUMS`. From the directory holding the downloaded files:

```bash
sha256sum -c SHA256SUMS        # Linux
shasum -a 256 -c SHA256SUMS    # macOS
```

From 1.5.1 on, a release can also be rebuilt from source: check out its tag, run `bash scripts/build.sh`, and `dist/SHA256SUMS` is identical to the published one. This needs Info-ZIP zip 3.0, the `zip` that ships with macOS and Ubuntu. Archives from 1.5.0 and earlier carry build-time timestamps, so a rebuild matches their contents but not their checksums.

## One skill, both platforms

There is no Claude version and ChatGPT version. Both products read the same `SKILL.md` frontmatter and the same `references/` folder, so a skill authored once installs in either.

```
skills/iterable-handlebars/
├── SKILL.md                 # frontmatter (name, description) + workflow
├── LICENSE                  # every archive is independently licensed
├── references/              # loaded on demand, not upfront
│   ├── helpers.md
│   ├── data-sources.md
│   ├── troubleshooting.md
│   └── figma-export.md      # generated from shared/ - see Contributing
├── agents/openai.yaml       # ChatGPT display metadata; Claude ignores it
└── evals/evals.json         # test prompts and assertions
```

For Claude's marketplace installs, each skill also has a plugin folder at `plugins/<name>/`: a `.claude-plugin/plugin.json` manifest plus a copy of the skill at `plugins/<name>/skills/<name>/`, which is the layout the Claude apps require. `scripts/sync_plugins.py` generates those folders from `skills/`, so there is still one copy to edit.

The one thing that isn't portable is *tools*. A skill that drives Figma or a browser only works where those tools exist. Everything in this repo is pure knowledge — no tool dependencies — so it runs anywhere.

## How these are built

Every skill is written against the platform's official documentation, then measured against a no-skill baseline before release. Each case runs twice — with the skill's content in context and without it — and a grader scores the response against that case's assertions one at a time.

41 cases, `claude-sonnet-4-5` on both arms and as grader, Claude Code CLI 2.1.239, full-context mode. One run: `evals-runs/baseline-v1.4.1/`, produced from this code with provenance (commit, hashes, exact commands) recorded in its `run.json`.

| Skill | Cases | With skill | Baseline | Delta |
|---|---:|---:|---:|---:|
| `moengage-jinja` | 4 | 86% | 23% | +63 |
| `hubspot-hubl` | 4 | 86% | 28% | +58 |
| `sailthru-zephyr` | 4 | 86% | 29% | +57 |
| `zeta-zml` | 4 | 89% | 34% | +55 |
| `braze-liquid` | 4 | 90% | 40% | +50 |
| `sfmc-ampscript` | 4 | 95% | 47% | +48 |
| `klaviyo-django` | 4 | 86% | 43% | +43 |
| `customerio-liquid` | 4 | 85% | 46% | +39 |
| `marketo-velocity` | 4 | 89% | 61% | +28 |
| `iterable-handlebars` | 5 | 84% | 66% | +18 |
| **All** | **41** | **88%** | **41%** | **+47** |

Assertion-weighted micro average 87.6% with skill against 41.0% baseline; equal-case macro 87.3% against 41.8%. Every prompt, response, per-assertion verdict, and raw grader output is committed under `evals-runs/baseline-v1.4.1/` — [`EVALS.md`](EVALS.md) has the schema, the commands, and the caveats.

**Routing is tested separately, and it is the harder property.** A skill that answers well but fires on the wrong platform is worse than no skill. `evals-runs/routing-v1.4.1/` holds 58 cases — the platform named, symptom-only phrasing, pasted code with no platform named, cross-platform confusables including the Zeta/Sailthru two-languages-one-vendor trap, and ten out-of-scope platforms that should trigger nothing. Result: **100% correct fire, 0% wrong-skill fire, 0% missed fire.** [`ROUTING.md`](ROUTING.md) has the method.

**These are smoke tests, not a benchmark.** Four or five cases per platform catches a regression and shows what the skill claims to fix. It cannot rank skills or prove a capability, and one run of one model gives no variance estimate. The with-skill arm loads the full skill content, which is an upper bound relative to runtime reference loading — the run records that mode explicitly.

The pattern across all ten: the baseline is better at *syntax* than at *consequences*. It usually knows the language. What it reliably misses is which mistakes cost you a send, where the platform records the failure, and what the platform's own documentation gets wrong. The largest deltas — MoEngage, HubSpot, Sailthru, Zeta — are the platforms where the language is least like anything a general model has seen, or where the governing rule (a null drops the user; filters don't apply to tokens in email) is undocumented folklore outside the vendor's own pages.

## Known limitations

**Customer.io unsubscribe tags, via the Email Love plugin — unverified.** Customer.io documents `{% unsubscribe_url %}` as a tag and states that the variable form `{{unsubscribe_url}}` "will render as empty text". Email Love's own [Customer.io export documentation](https://help.emaillove.com/plugin/export/customerio) says the plugin swaps the footer link for `{{unsubscribe_url}}` — the variable form. If the plugin really emits that, a Figma-exported Customer.io email ships with an empty unsubscribe link, which is a compliance problem and not a cosmetic one.

We could not resolve this from the outside: it needs one Figma file exported through the current plugin to Customer.io, and the exported HTML read. Until someone does that, this skill follows Customer.io's documented syntax, and the Figma reference says so explicitly. If you have both halves, [tell us what you see](../../issues).

**Nothing here has been through a stable release.** The eval suites are small, the guidance on trust boundaries is new, and no platform behaviour has been re-verified on a schedule yet.

## Contributing

ESPs change. If a skill tells you something that's no longer true, [open an issue](../../issues) with the platform, the skill's claim, and a link to the current docs — that's the most useful contribution here.

Adding a platform:

```bash
python3 -m pip install pyyaml==6.0.2
python3 scripts/validate.py          # frontmatter, metadata, evals, versions, hygiene
python3 scripts/sync_shared.py       # regenerate the blocks shared by every skill
python3 scripts/sync_plugins.py      # regenerate the plugin folders in plugins/
bash scripts/build.sh                # package every skill into dist/*.skill
bash scripts/verify_dist.sh          # zip integrity, inventory, licence, checksums
```

Two blocks are shared between all ten skills and generated rather than hand-edited: `references/figma-export.md`, and the "Handling untrusted content" section in each `SKILL.md`. Edit them in `shared/` and run `scripts/sync_shared.py`. CI runs `--check` and fails on drift.

The plugin folders in `plugins/` are generated too. Edit the skill in `skills/<name>/`, or its entry in `.claude-plugin/marketplace.json`, then run `scripts/sync_plugins.py`. CI runs `--check` on those as well.

Changing the version means editing `VERSION`, every `version` in `.claude-plugin/marketplace.json`, and adding a matching `## [x.y.z]` section to `CHANGELOG.md`. Then run `scripts/sync_plugins.py` to carry the version into each `plugin.json`. The validator checks that all of them agree, and that every plugin still has the layout the Claude apps require.

Keep `SKILL.md` under ~500 lines and push lookup tables into `references/` — both platforms load reference files on demand, so depth there is close to free while depth in `SKILL.md` is paid on every trigger.

## Also from Email Love

[**email-love/claude-skills**](https://github.com/email-love/claude-skills) — skills for building production emails in Figma with the Email Love plugin: design system migration, audits, and export-ready email assembly.

[**emaillove.com**](https://www.emaillove.com) — curated email design inspiration, and the Figma plugin that turns your designs into production code.

## License

MIT
